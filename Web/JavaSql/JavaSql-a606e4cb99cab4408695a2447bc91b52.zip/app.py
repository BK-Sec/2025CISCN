from flask import Flask, request
import requests
import json
app = Flask(__name__)


def proxy_request(data, header, path, method='POST'):
    if type(header) == str:
        header = {"Auth-Key": header}
    target_url = f"http://127.0.0.1:18081/{path}"
    try:
        if method.upper() == 'POST':
            response = requests.request(method, target_url, json=data, headers=header)
        else:
            response = requests.request(method, target_url, params=data, headers=header)
        return dict(response.headers), response.content, response.status_code
    except Exception as e:
        return {"error": str(e)}, b"", 500

@app.route('/check_username', methods=['GET'])
def check_username():
    params = dict(request.args)
    _, _, status_code = proxy_request(params, {}, 'check_username', request.method)
    return str(status_code == 200), status_code

@app.route('/get_bin_data/<path:path>', methods=['GET', 'POST'])
def get_bin_data(path):
    params = dict(request.args)
    post = request.get_data()
    try:
        params.update(json.loads(post))
    except Exception as e:
        pass
    auth_key = params.pop('auth_key', '')
    if auth_key == '':
        return "auth_key is required", 400
    response_headers, response, status_code = proxy_request(params, auth_key, path, request.method)
    if len(response) > 1024 * 100:
        return "文件过大", 500
    if (response_headers.get('Content-Type').startswith('application/octet-stream')):
        return response, status_code, response_headers
    return "该接口仅用于下载文件", 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)
