USE CTF;
CREATE TABLE config (
    `id` INT PRIMARY KEY,
    `key` VARCHAR(50),
    `value` VARCHAR(100),
    `bin_data` MEDIUMBLOB DEFAULT NULL
);

INSERT INTO config(`id`,`key`,`value`) VALUES 
(1, 'secretKey', CONCAT('secretkey-sk-', SHA2(CONCAT(RAND(), NOW()), 256)));

INSERT INTO config(`id`,`key`,`bin_data`) VALUES 
(2, 'obj', unhex('74657374'));

CREATE TABLE user (
    `id` INT PRIMARY KEY,
    `username` VARCHAR(50),
    `password` VARCHAR(50),
    `email` VARCHAR(100)
);

INSERT INTO user VALUES 
(1, 'admin', 'admin','admin@qq.com');